<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Products;

class AdminProductController extends Controller
{
    public function getListProduct() {
    	$products = new Products();
    	$product = $products->getData();

    	return view('admin.admin_list_product', array('product' => $product));
    }
    
    public function add(Request $request){
        $name = $request->input('product_name');
        if ($name != null)
        {
            $obj = new Products();
            $product = $obj->addProduct($name);

            return redirect()->to('/admin/products');
        }
        
        return view('admin.action.add');
    }
    public function deleteData(Request $request){
        $id = $request->input('product_id');
        $obj = new Products();
        $product = $obj->deleteProduct($id);
        return redirect()->to('/admin/products');
    }

    public function editView(Request $request){
        $id = $request->input('product_id');
        $obj = new Products();
        $product = $obj->getID($id);
        return view('admin.action.edit', array('products' => $product));
    }

    public function updateData(Request $request){        
        $id = $request->input('product_id');
        $name = $request->input('product_name');
        
        $obj = new Products();
        $product = $obj->updateProduct($id, $name);
        return redirect()->to('/admin/products');
    }
}
