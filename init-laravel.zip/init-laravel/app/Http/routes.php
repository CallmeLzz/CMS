<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/admin', 'AdminController@getAdmin');

Route::get('/admin/products', 'AdminProductController@getListProduct');



Route::get('url/asset', function() {
	return asset('css/style.css');
});

Route::get('url/asset', function() {
	return asset('css/bootstrap.min.css');
});

Route::get('url/asset', function() {
	return asset('css/font-awesome.min.css');
});

Route::get('url/asset', function() {
	return asset('css/insert.css');
});

Route::get('url/asset', function() {
	return asset('css/update.css');
});

Route::get('/admin/add', 'AdminProductController@add');

Route::get('/admin/delete', 'AdminProductController@deleteData');

Route::get('/admin/editView', 'AdminProductController@editView');

Route::get('/admin/update', 'AdminProductController@updateData');
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {
    //
});
