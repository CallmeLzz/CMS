<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Products extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'product_id';
    public $timestamps = false;
    protected $filltable = [
    	'product_id',
    	'product_name',
    ];
    protected $quarded = ['product_id'];
    public function getData() {
    	return self::all();
    }

    public function getID($id){
        return self::find($id)->get();
    }

    public function addProduct($name){
        $product = new self();      
        $product->product_name = $name;
        $product->save();
    }

    public function deleteProduct($id){
        self::find($id)->delete();
    }

    public function updateProduct($id, $name) {
        self::where('product_id', $id)->update(array('product_name' => $name));
    }
}
