<?php $__env->startSection('title', 'Page admin'); ?>
<?php $__env->startSection('menu'); ?>
	<?php echo $__env->make('admin.admin.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('slidebar-left'); ?>
	<?php echo $__env->make('admin.admin.slidebarleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
	<?php echo $__env->make('admin.admin.maincontent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('slidebar-right'); ?>
	<?php echo $__env->make('admin.admin.slidebarright', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.masterpage.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>