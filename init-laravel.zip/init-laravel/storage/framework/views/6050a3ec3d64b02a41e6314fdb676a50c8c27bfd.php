<html>
	<head>
		<title><?php echo $__env->yieldContent('title'); ?></title>
		<?php echo $__env->make('admin.masterpage.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</head>
	<body>
		<?php echo $__env->yieldContent('menu'); ?>
		<div class="content">
			<div class="container">
				<div class="row">
					<?php echo $__env->yieldContent('slidebar-left'); ?>
					<?php echo $__env->yieldContent('main-content'); ?>
					<?php echo $__env->yieldContent('slidebar-right'); ?>
				</div>
			</div>
		</div>
	</body>
</html>