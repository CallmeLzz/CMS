
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/insert.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/update.css')); ?>" rel="stylesheet" type="text/css" />

