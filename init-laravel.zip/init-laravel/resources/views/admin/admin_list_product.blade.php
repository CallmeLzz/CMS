@extends('admin.masterpage.masterpage')
@section('title', 'Page admin')
@section('menu')
	@include('admin.admin.menu')
@stop
@section('slidebar-left')
	@include('admin.admin.slidebarleft')
@stop
@section('main-content')
	@include('admin.admin.maincontent')
@stop
@section('slidebar-right')
	@include('admin.admin.slidebarright')
@stop
