<html>
	<head>
		<title>@yield('title')</title>
		@include('admin.masterpage.head')
	</head>
	<body>
		@yield('menu')
		<div class="content">
			<div class="container">
				<div class="row">
					@yield('slidebar-left')
					@yield('main-content')
					@yield('slidebar-right')
				</div>
			</div>
		</div>
	</body>
</html>