<div class="col-md-6 main-content">
   <div class="admin-info">
        <table class="table-fill">
            <thead>
                <tr>
                    <th class="text-left">ID</th>
                    <th class="text-left">Name</th>
                    <th class="text-left">Modify</th>
                </tr>
            </thead>
            <tbody class="table-hover">
                @foreach($product as $row)
                    <tr>
                        <td>{{ $row->product_id }}</td>
                        <td>{{ $row->product_name }}</td>

                        <td>
                            <a href="editView?product_id=<?php echo $row->product_id ?>" title="Edit"><i class="fa fa-edit"></i></a>
                            <a href="delete?product_id=<?php echo $row->product_id ?>" title="Remove"><i class="fa fa-remove"></i></a>
                        </td>
                    </tr>
                @endforeach               
            </tbody>
        </table>
    </div>
</div>