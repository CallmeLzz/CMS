<header class="topheader">
    <div class="container">
        <nav class="main-menu">
            <ul>
                <li><a href="index.php">Menu 1</a></li>
                <li><a href="index.php">Menu 2</a></li>
                <li><a href="index.php">Menu 3</a></li>
            </ul>
        </nav>
    </div>
</header>