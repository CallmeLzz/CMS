
<div class="col-md-3 slidebar-left">
    <a class="add-post" href="add" title="Add"><i class="fa fa-plus"></i>Add</a>
</div>     
