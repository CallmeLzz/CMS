<div class="col-md-3 slidebar-right">
    <form method="get" action="#">
        <input type="text" name="search" id="search" placeholder="Search..."><i class="fa fa-search" title="Search"></i>
    </form>
</div>
