
        <div class="formupdate">
            <div class="container">
                <form method="get" action="updateData">
                    <label>Product name</label>
                    <input type="text" name="product_name" id="product_name" placeholder="Enter product name...">
                    <input type="submit" id="submit" value="Update">
                </form>
            </div>
        </div>