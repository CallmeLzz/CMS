@extends('admin.masterpage.masterpage')

@section('main-content')
    @include('admin.action.update')
@stop	