@extends('admin.masterpage.masterpage')

@section('main-content')
   @include('admin.action.insert')
@stop