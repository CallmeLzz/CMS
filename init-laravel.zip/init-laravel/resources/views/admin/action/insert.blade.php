        <div class="forminsert">
            <div class="container">
                <form action="" method="get">
                    <label>Product name</label>
                    <input type="text" name="product_name" id="product_name" placeholder="Enter product name...">
                    
                    <input type="submit" id="submit" value="Add">
                </form>
            </div>
        </div>